# Data
Expected input: a CSV `data/sequences.csv` with two columns:

| sequence | label |
|---|---|
| ACGTTGCA... | 0 |
| TTGACCGA... | 1 |

`label` = 1 means the sequence is associated with the disease class, 0 means not.

No real dataset yet? Generate a synthetic demo file (for testing the pipeline only, not for real conclusions):
```bash
python src/generate_demo_data.py
```
Real sources: NCBI GenBank / ClinVar, Kaggle DNA sequence classification datasets. Never commit patient-identifiable data.
