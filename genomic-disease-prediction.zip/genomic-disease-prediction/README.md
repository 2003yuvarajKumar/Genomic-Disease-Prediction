# Genomic AI Disease Prediction System (Python, TensorFlow, LSTM)

A deep learning system that predicts genetic disease risk from DNA sequence data using a bidirectional LSTM, and returns a risk probability with a simple recommendation.

> **Disclaimer:** Educational/research project. It is not a medical device and must not be used for diagnosis.

## Highlights
- DNA preprocessing: integer encoding (A, C, G, T), padding/truncation to a fixed length
- Bidirectional LSTM classifier built in TensorFlow/Keras
- Evaluation with accuracy, precision, recall
- CLI prediction script that outputs risk probability and a recommendation

## Project Structure
```
genomic-disease-prediction/
├── data/                     # sequences.csv (see data/README.md)
├── docs/data_dictionary.md
├── models/                   # trained model (not committed)
├── outputs/                  # training curves
├── src/
│   ├── generate_demo_data.py # synthetic data for testing the pipeline
│   ├── preprocess.py
│   ├── train_lstm.py
│   └── predict.py
├── requirements.txt
└── LICENSE
```

## How to Run
```bash
git clone https://github.com/<your-username>/genomic-disease-prediction.git
cd genomic-disease-prediction
pip install -r requirements.txt

python src/generate_demo_data.py          # or put your own data/sequences.csv
python src/train_lstm.py --epochs 10
python src/predict.py --sequence ACGTACGTGATTACAGATTACA...
```

## Results
_Paste your test accuracy / precision / recall here and add `outputs/training_loss.png`._
Note: results on the synthetic demo data are not meaningful; report results from your real dataset only.

## Future Improvements
- k-mer embeddings or CNN-LSTM hybrid
- Larger, curated datasets (ClinVar / GenBank)
- Model explainability (saliency on sequence positions)

## Author
**Yuvaraj Kumar** | [LinkedIn](https://linkedin.com/in/yuvarajkumar-m) | yuvarajkumarm442@gmail.com
