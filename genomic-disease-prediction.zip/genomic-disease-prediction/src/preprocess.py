"""DNA preprocessing helpers: integer encoding, padding, train/test split."""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.sequence import pad_sequences

BASE_TO_INT = {"A": 1, "C": 2, "G": 3, "T": 4}
VOCAB_SIZE = 5  # 0 = padding / unknown
MAX_LEN = 200


def encode(seq: str) -> list:
    return [BASE_TO_INT.get(b, 0) for b in str(seq).upper().strip()]


def load_dataset(path: str, max_len: int = MAX_LEN, test_size: float = 0.2, seed: int = 42):
    df = pd.read_csv(path).dropna(subset=["sequence", "label"]).drop_duplicates()
    X = pad_sequences([encode(s) for s in df["sequence"]], maxlen=max_len,
                      padding="post", truncating="post")
    y = df["label"].astype(int).values
    return train_test_split(X, y, test_size=test_size, stratify=y, random_state=seed)
