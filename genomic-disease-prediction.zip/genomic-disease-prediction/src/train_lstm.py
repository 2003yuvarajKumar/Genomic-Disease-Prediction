"""Train an LSTM to classify DNA sequences into risk classes.

Usage: python src/train_lstm.py --input data/sequences.csv --epochs 10
"""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from tensorflow import keras
from tensorflow.keras import layers

from preprocess import MAX_LEN, VOCAB_SIZE, load_dataset


def build_model():
    model = keras.Sequential([
        layers.Input(shape=(MAX_LEN,)),
        layers.Embedding(VOCAB_SIZE, 32, mask_zero=True),
        layers.Bidirectional(layers.LSTM(64)),
        layers.Dropout(0.3),
        layers.Dense(32, activation="relu"),
        layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy",
                  metrics=["accuracy", keras.metrics.Precision(name="precision"),
                           keras.metrics.Recall(name="recall")])
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/sequences.csv")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--batch", type=int, default=32)
    args = ap.parse_args()

    X_train, X_test, y_train, y_test = load_dataset(args.input)
    model = build_model(); model.summary()

    hist = model.fit(X_train, y_train, validation_split=0.1, epochs=args.epochs,
                     batch_size=args.batch,
                     callbacks=[keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True)])

    print(classification_report(y_test, (model.predict(X_test) > 0.5).astype(int),
                                target_names=["Low risk", "High risk"]))

    Path("models").mkdir(exist_ok=True); Path("outputs").mkdir(exist_ok=True)
    model.save("models/lstm_model.keras")
    for m in ["loss", "accuracy"]:
        plt.plot(hist.history[m], label="train"); plt.plot(hist.history[f"val_{m}"], label="val")
        plt.title(m); plt.legend(); plt.savefig(f"outputs/training_{m}.png", dpi=150); plt.close()


if __name__ == "__main__":
    main()
