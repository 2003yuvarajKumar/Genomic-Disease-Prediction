"""Create a small SYNTHETIC dataset so the pipeline can run end to end.
Label 1 sequences contain an injected motif. This is demo data only."""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
MOTIF = "GATTACAGATTACA"
n, length = 2000, 200
rows = []
for _ in range(n):
    seq = "".join(rng.choice(list("ACGT"), size=length))
    label = int(rng.random() < 0.5)
    if label:
        pos = rng.integers(0, length - len(MOTIF))
        seq = seq[:pos] + MOTIF + seq[pos + len(MOTIF):]
    rows.append((seq, label))
pd.DataFrame(rows, columns=["sequence", "label"]).to_csv("data/sequences.csv", index=False)
print("Saved data/sequences.csv (synthetic demo data)")
