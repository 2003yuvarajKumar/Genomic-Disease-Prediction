"""Predict disease risk for a single DNA sequence and print a simple recommendation.

Usage: python src/predict.py --sequence ACGTACGT...
"""
import argparse

import numpy as np
from tensorflow import keras
from tensorflow.keras.preprocessing.sequence import pad_sequences

from preprocess import MAX_LEN, encode


def recommend(p: float) -> str:
    if p >= 0.7:
        return "High predicted risk: consult a genetic counsellor / clinician for confirmatory testing."
    if p >= 0.4:
        return "Moderate predicted risk: consider routine screening and follow-up."
    return "Low predicted risk: maintain regular health check-ups."


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sequence", required=True)
    ap.add_argument("--model", default="models/lstm_model.keras")
    args = ap.parse_args()

    model = keras.models.load_model(args.model)
    x = pad_sequences([encode(args.sequence)], maxlen=MAX_LEN, padding="post", truncating="post")
    p = float(model.predict(x, verbose=0)[0][0])
    print(f"Predicted risk probability: {p:.2%}")
    print(recommend(p))
    print("Disclaimer: research/educational project, not a medical diagnosis.")


if __name__ == "__main__":
    main()
