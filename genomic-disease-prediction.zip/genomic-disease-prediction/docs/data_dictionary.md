# Data Dictionary
| Column | Description |
|---|---|
| sequence | DNA string using A, C, G, T (N or unknown bases are mapped to a padding value) |
| label | 0 = low-risk class, 1 = high-risk class |

Preprocessing: sequences are cut or padded to a fixed length and converted to integer-encoded tokens (A=1, C=2, G=3, T=4, other=0).
