# Data
Raw data is not committed. Download the global layoffs dataset (columns below) from Kaggle ("Layoffs 2022") or layoffs.fyi and save as `data/layoffs.csv`.

Expected columns: company, location, industry, total_laid_off, percentage_laid_off, date, stage, country, funds_raised_millions
