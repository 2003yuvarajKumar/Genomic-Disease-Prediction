"""EDA charts for the cleaned layoffs dataset.

Usage: python src/eda.py --input data/layoffs_cleaned.csv
"""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

sns.set_theme(style="whitegrid")


def load(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["date"])
    df["total_laid_off"] = pd.to_numeric(df["total_laid_off"], errors="coerce")
    df = df.dropna(subset=["date"])
    df["year"] = df["date"].dt.year
    return df


def yearly_trend(df, out):
    yearly = df.groupby("year")["total_laid_off"].sum()
    print("\nYearly totals:\n", yearly)
    print("\nYoY % change:\n", yearly.pct_change().mul(100).round(1))
    ax = yearly.plot(kind="bar", color="#2b6cb0", figsize=(8, 5))
    ax.set(title="Total Layoffs by Year", xlabel="Year", ylabel="Employees laid off")
    plt.tight_layout(); plt.savefig(out / "yearly_trend.png", dpi=150); plt.close()


def top_n(df, col, out, n=10):
    top = df.groupby(col)["total_laid_off"].sum().nlargest(n).sort_values()
    top.plot(kind="barh", figsize=(8, 5), color="#dd6b20")
    plt.title(f"Top {n} {col.title()} by Layoffs")
    plt.xlabel("Employees laid off")
    plt.tight_layout(); plt.savefig(out / f"top_{col}.png", dpi=150); plt.close()


def country_share(df):
    share = df.groupby("country")["total_laid_off"].sum()
    share = (share / share.sum() * 100).round(1).sort_values(ascending=False)
    print("\nShare of layoffs by country (%):\n", share.head(5))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/layoffs_cleaned.csv")
    ap.add_argument("--out", default="outputs")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(exist_ok=True)

    df = load(args.input)
    print(f"Loaded {len(df):,} records")
    yearly_trend(df, out)
    for col in ["industry", "country", "company"]:
        top_n(df, col, out)
    country_share(df)
    print(f"\nCharts saved to {out}/")


if __name__ == "__main__":
    main()
