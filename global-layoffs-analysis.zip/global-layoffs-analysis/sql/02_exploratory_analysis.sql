-- 02_exploratory_analysis.sql

-- Overview
SELECT MAX(total_laid_off), MAX(percentage_laid_off) FROM layoffs_staging2;

-- Companies that shut down completely, biggest funding first
SELECT * FROM layoffs_staging2
WHERE percentage_laid_off = 1 ORDER BY funds_raised_millions DESC;

-- Total layoffs by company / industry / country / stage
SELECT company,  SUM(total_laid_off) AS total FROM layoffs_staging2 GROUP BY company  ORDER BY total DESC;
SELECT industry, SUM(total_laid_off) AS total FROM layoffs_staging2 GROUP BY industry ORDER BY total DESC;
SELECT country,  SUM(total_laid_off) AS total FROM layoffs_staging2 GROUP BY country  ORDER BY total DESC;
SELECT stage,    SUM(total_laid_off) AS total FROM layoffs_staging2 GROUP BY stage    ORDER BY total DESC;

-- Share of layoffs by country (e.g. US share)
SELECT country,
       SUM(total_laid_off) AS total,
       ROUND(100 * SUM(total_laid_off) / SUM(SUM(total_laid_off)) OVER (), 1) AS pct_share
FROM layoffs_staging2
GROUP BY country ORDER BY total DESC;

-- Year over year change
WITH yearly AS (
  SELECT YEAR(`date`) AS yr, SUM(total_laid_off) AS total
  FROM layoffs_staging2 WHERE `date` IS NOT NULL GROUP BY yr
)
SELECT yr, total,
       LAG(total) OVER (ORDER BY yr) AS prev_total,
       ROUND(100 * (total - LAG(total) OVER (ORDER BY yr)) / LAG(total) OVER (ORDER BY yr), 1) AS yoy_pct
FROM yearly;

-- Rolling monthly total (CTE + window function)
WITH monthly AS (
  SELECT SUBSTRING(`date`, 1, 7) AS month, SUM(total_laid_off) AS total
  FROM layoffs_staging2 WHERE `date` IS NOT NULL GROUP BY month
)
SELECT month, total, SUM(total) OVER (ORDER BY month) AS rolling_total
FROM monthly ORDER BY month;

-- Top 5 companies per year
WITH company_year AS (
  SELECT company, YEAR(`date`) AS yr, SUM(total_laid_off) AS total
  FROM layoffs_staging2 WHERE `date` IS NOT NULL GROUP BY company, yr
),
ranked AS (
  SELECT *, DENSE_RANK() OVER (PARTITION BY yr ORDER BY total DESC) AS rnk
  FROM company_year WHERE total IS NOT NULL
)
SELECT * FROM ranked WHERE rnk <= 5;
