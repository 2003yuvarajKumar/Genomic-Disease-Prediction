# Data Dictionary
| Column | Type | Description |
|---|---|---|
| company | text | Company name |
| location | text | City / HQ location |
| industry | text | Industry category |
| total_laid_off | int | Number of employees laid off |
| percentage_laid_off | float | Share of workforce laid off (0-1) |
| date | date | Date of layoff announcement |
| stage | text | Funding stage (e.g. Post-IPO, Series B) |
| country | text | Country |
| funds_raised_millions | float | Funds raised in USD millions |
